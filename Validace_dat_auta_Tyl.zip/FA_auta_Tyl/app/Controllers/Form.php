<?php

namespace App\Controllers;
use App\Models\Model_form;
use CodeIgniter\Controller;

class Form extends BaseController
{

    public function form() {
        return view('form');
    }
 
    public function validation() {
        helper(['form', 'url']);
        
        $input = $this->validate([
            'nazev'			=>	'required',
			'vyroba'		=>	'required|numeric',
			'barva'	        =>	'required'
        ]);

        $Model_form = new Model_form();
 
        if (!$input) {
            echo view('form', [
                'validation' => $this->validator
            ]);
        } else {
            $Model_form->save([
                "nazev"     =>$this->request->getVar("nazev"),  
                "vyroba"  =>$this->request->getVar("vyroba"),
                "barva"     =>$this->request->getVar("barva"),
                "prevodovka"     =>$this->request->getVar("prevodovka") 
            ]);          

            return $this->response->redirect(site_url('Form/validation'));
        }
    }

}
