<?php 

namespace App\Models;
use CodeIgniter\Model;

class Model_form extends Model
{
    protected $table = 'auta';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nazev', 'vyroba', 'barva', 'prevodovka'];
    
}