<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Auta</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <style>
    .container {
      max-width: 550px;
      margin-top: 13rem;
      margin-right: 80rem;
    }
    body
    {
      background-image: url(https://wallpapercave.com/wp/wp2552873.jpg);
      background-repeat: no-repeat;
      background-attachment: fixed;
      background-position: center;
      background-size: cover;
      position: relative;
      overflow: hidden;
      
    }
  </style>
</head>

<body>
  <div class="container">
         
    <?php $validation = \Config\Services::validation(); ?>

    <form method="post" action="<?php echo base_url("/validation"); ?>">
      <div class="form-group">
        <label>Název</label>
        <input type="text" name="nazev" class="form-control">

        <!-- Error -->
        <?php if($validation->getError('nazev')) {?>
            <div class='alert alert-danger mt-2'>
              <?= $error = $validation->getError('nazev'); ?>
            </div>
        <?php }?>
      </div>
       

      <div class="form-group">
        <label>Rok výroby</label>
        <input type="text" name="vyroba" class="form-control">

        <!-- Error -->
        <?php if($validation->getError('vyroba')) {?>
            <div class='alert alert-danger mt-2'>
              <?= $error = $validation->getError('vyroba'); ?>
            </div>
        <?php }?>
      </div>

      <div class="form-group">
        <label>Barva</label>
        <input type="text" name="barva" class="form-control">

        <!-- Error -->
        <?php if($validation->getError('barva')) {?>
            <div class='alert alert-danger mt-2'>
              <?= $error = $validation->getError('barva'); ?>
            </div>
        <?php }?>
      </div>
                <div class="form-group">   
                    <label>Typ převodovky</label>
                    <select name="prevodovka"  class="form-control">
                        <option value="1">Manuál</option>
                        <option value="0">Automat</option>
                    </select>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-success btn-block">Vložit</button>
                </div>
            </div>
         </div>
    </form>
  </div>
</body>

</html>